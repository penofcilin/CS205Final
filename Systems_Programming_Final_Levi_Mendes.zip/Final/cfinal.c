//Levi Mendes
//CS205
//Final
//3.14.2024
//This is a C implementation of the game "Mastermind"

#include <stdint.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>

/* Period parameters */  
#define N 624
#define M 397
#define MATRIX_A 0x9908b0dfUL   /* constant vector a */
#define UPPER_MASK 0x80000000UL /* most significant w-r bits */
#define LOWER_MASK 0x7fffffffUL /* least significant r bits */

#define MAX_GUESSES 5

static unsigned long mt[N]; /* the array for the state vector  */
static int mti=N+1; /* mti==N+1 means mt[N] is not initialized */

static int wins;
static int losses;

/* initializes mt[N] with a seed */
void init_genrand(unsigned long s)
{
	mt[0]= s & 0xffffffffUL;
	for (mti=1; mti<N; mti++) {
		mt[mti] = 
			(1812433253UL * (mt[mti-1] ^ (mt[mti-1] >> 30)) + mti); 
		/* See Knuth TAOCP Vol2. 3rd Ed. P.106 for multiplier. */
		/* In the previous versions, MSBs of the seed affect   */
		/* only MSBs of the array mt[].                        */
		/* 2002/01/09 modified by Makoto Matsumoto             */
		mt[mti] &= 0xffffffffUL;
		/* for >32 bit machines */
	}
}

/* initialize by an array with array-length */
/* init_key is the array for initializing keys */
/* key_length is its length */
/* slight change for C++, 2004/2/26 */
void init_by_array(unsigned long init_key[], int key_length)
{
	int i, j, k;
	init_genrand(19650218UL);
	i=1; j=0;
	k = (N>key_length ? N : key_length);
	for (; k; k--) {
		mt[i] = (mt[i] ^ ((mt[i-1] ^ (mt[i-1] >> 30)) * 1664525UL))
			+ init_key[j] + j; /* non linear */
		mt[i] &= 0xffffffffUL; /* for WORDSIZE > 32 machines */
		i++; j++;
		if (i>=N) { mt[0] = mt[N-1]; i=1; }
		if (j>=key_length) j=0;
	}
	for (k=N-1; k; k--) {
		mt[i] = (mt[i] ^ ((mt[i-1] ^ (mt[i-1] >> 30)) * 1566083941UL))
			- i; /* non linear */
		mt[i] &= 0xffffffffUL; /* for WORDSIZE > 32 machines */
		i++;
		if (i>=N) { mt[0] = mt[N-1]; i=1; }
	}

	mt[0] = 0x80000000UL; /* MSB is 1; assuring non-zero initial array */ 
}

/* generates a random number on [0,0xffffffff]-interval */
unsigned long genrand_int32(void)
{
	unsigned long y;
	static unsigned long mag01[2]={0x0UL, MATRIX_A};
	/* mag01[x] = x * MATRIX_A  for x=0,1 */

	if (mti >= N) { /* generate N words at one time */
		int kk;

		if (mti == N+1)   /* if init_genrand() has not been called, */
			init_genrand(5489UL); /* a default initial seed is used */

		for (kk=0;kk<N-M;kk++) {
			y = (mt[kk]&UPPER_MASK)|(mt[kk+1]&LOWER_MASK);
			mt[kk] = mt[kk+M] ^ (y >> 1) ^ mag01[y & 0x1UL];
		}
		for (;kk<N-1;kk++) {
			y = (mt[kk]&UPPER_MASK)|(mt[kk+1]&LOWER_MASK);
			mt[kk] = mt[kk+(M-N)] ^ (y >> 1) ^ mag01[y & 0x1UL];
		}
		y = (mt[N-1]&UPPER_MASK)|(mt[0]&LOWER_MASK);
		mt[N-1] = mt[M-1] ^ (y >> 1) ^ mag01[y & 0x1UL];

		mti = 0;
	}
  
	y = mt[mti++];

	/* Tempering */
	y ^= (y >> 11);
	y ^= (y << 7) & 0x9d2c5680UL;
	y ^= (y << 15) & 0xefc60000UL;
	y ^= (y >> 18);

	return y;
}

/* generates a random number on [0,0x7fffffff]-interval */
long genrand_int31(void)
{
	return (long)(genrand_int32()>>1);
}

/* generates a random number on [0,1]-real-interval */
double genrand_real1(void)
{
	return genrand_int32()*(1.0/4294967295.0); 
	/* divided by 2^32-1 */ 
}

/* generates a random number on [0,1)-real-interval */
double genrand_real2(void)
{
	return genrand_int32()*(1.0/4294967296.0); 
	/* divided by 2^32 */
}

/* generates a random number on (0,1)-real-interval */
double genrand_real3(void)
{
	return (((double)genrand_int32()) + 0.5)*(1.0/4294967296.0); 
	/* divided by 2^32 */
}

/* generates a random number on [0,1) with 53-bit resolution*/
double genrand_res53(void) 
{ 
	unsigned long a=genrand_int32()>>5, b=genrand_int32()>>6; 
	return(a*67108864.0+b)*(1.0/9007199254740992.0); 
} 

//Forward declaration
void beginGame();

//Function just prints the intro
void printIntro()
{
    char response;
    
    printf("\n");
    printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
    printf("Welcome to mastermind! This is a game about guessing a secret code!\n");
    printf("I'm going to come up with 6 random numbers (in hex! each number could be 0, f) and it's your job to guess! \n");
    printf("If you get one of the numbers right, I'll tell you (X). If you only get the position right, I'll tell you that too (O).\n");
    printf("Be careful though, you only get 5 tries to guess the final code!\n");
    printf("Good luck!\n");
    printf("Ready to begin?\n");
    printf("Enter y to begin->");
    scanf("%c", &response);

    response = toupper(response);

    //check if they are ready to go
    if (response == 'Y') 
    {
        printf("Starting game...\n");
    } 
    else 
    {
        printf("Quitting!\n");
        exit(0);
    }
}

//Prompts the user if they'd like to restart the game.
void restartPrompt()
{
	char response;
	printf("Your current score is %d wins and %d losses.\n", wins, losses);
	printf("Would you like to play again?\n");
	printf("Enter y to play again->");
	scanf("%c", &response);
	scanf("%c", &response);
	

	response = toupper(response);

	if(response == 'Y')
	{
		printf("\n");
		beginGame();
	}
	else
	{
		printf("Thanks for playing, goodbye!\n");
		exit(0);
	}
}

void win()
{
	printf("Congratulations! You guessed it right!\n");
	wins++;
	restartPrompt();
}

void lose()
{
	losses++;
	restartPrompt();
}

//This function will get correct input from the user, a 6 character hex string. It will force new input
//if the input is more or less than 6 characters, and if one of those characters isn't a valid hex digit.
void getValidInput(char* guess)
{
	int isValid = 1;

	do
	{
		isValid = 1;
		printf("Enter your guess->");
		scanf("%s", guess);
		printf("\n");
		//validate if it's hex input
		for(int i = 0; i < 6; i++)
		{
			if(!isxdigit(guess[i]))
			{
				isValid = 0;
			}
		}
		//validate that it's 6 chars
		if(strlen(guess) > 6 || strlen(guess) < 6)
		{
			isValid = 0;
		}
		if(!isValid)
			printf("Sorry, your guess has to be 6 HEX characters. Try again.\n");
	}
	while(!isValid);
}

//This function handles checking the guess against the code, and formatting the result string correctly.
int guessLoop(char* code, char* result)
{
	char guess[100] __attribute__((unused));
	
	getValidInput(guess);

	for(int i = 0; i < 6; i++)
	{
		guess[i] = toupper(guess[i]);
	}

    printf("Your guess is: %s\n", guess);

	//check if the guesses are in there
	for(int i = 0; i < 6; i++)
	{
		//Check if the guess is correct in that spot
		if(guess[i] == code[i])
		{
			result[i] = 'X';
			code[i] = 'S'; //for solved
		}
		//Check if the guess digit is right anywhere in the whole code string
		else
		{
			if(result[i] != 'X')
			{
				for(int b = 0; b < 6; b++)
			{
				if(guess[i] == code[b])
				{
					result[i] = 'O';
					break;
				}
				else if(b == 5)
				{
					result[i] = '-';
				}
			}

			if(result[i] != 'O')
				result[i] = '-';
			}
			
		}
	}

	//check if its the correct guess
	int incomplete = 0;
	for(int i = 0; i < 6; i++)
	{
		if(result[i] != 'X')
			{
				incomplete = 1;
				break;
			}
	}

	if(!incomplete)
	{
		win();
		return 1;
	}

	printf("Not quite! Your guess: %s\n", result);
	return 0;
}

//This function handles the generation of a code, converts it to a char string, then calls the guessloop
void beginGame()
{
    //generate code
    char code[6] __attribute__((unused)); //<-wtf?
	char originalcode[6] __attribute__((unused));
    uint32_t myrandom;

	//this will generate a code, and actually convert them to characters.
    for(int i = 0; i < 6; i++)
    {
        myrandom = genrand_int32();
        myrandom %= 16;

		if(myrandom >= 0 && myrandom <=9)
		{
			myrandom = myrandom + '0';
		}
		else if (myrandom >= 10)
			myrandom = myrandom - 10 + 'A';

        code[i] = myrandom;
		originalcode[i] = myrandom;

        	//printf("Code digit %d is %c\n", i, myrandom); //Uncomment to have the code print <- !!!
    }

	
	printf("I've got a code i'm thinking of...\n");

	//the result string will store if they've got it correct/kind of correct etc.
	char result[] = "------";
	int returnCode = 0;

	//loop through the guessloop for as many times as you have guesses
	for(int m = 0; m < MAX_GUESSES; m++)
	{
		returnCode = guessLoop(code, result);
		if(returnCode)
		{
			return;
		}
	}

	//If returncode was 0, they didn't get it right.
	if(returnCode == 0)
	{
		printf("Out of guesses! Sorry, the code was ");
		for(int i = 0; i < 12; i++)
		{
			if(i > 5)
				printf("%c", code[i]);
		}
		printf("\n");
		lose();
	}
}

int main()
{
	losses = 0;
	wins = 0;
    init_genrand(1234);
    
    printIntro();
    beginGame();
    

    return 0;
}

